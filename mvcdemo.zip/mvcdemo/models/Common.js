exports.list = function(tablename){
	var db = require('../config/db.js');
    db.connect(function(err) {
    if (err) throw err;
        db.query("SELECT * FROM users where eStatus!='Deleted'", function (err, result, fields) {
            if (err) throw err;
            return result;
        });
    });    
};