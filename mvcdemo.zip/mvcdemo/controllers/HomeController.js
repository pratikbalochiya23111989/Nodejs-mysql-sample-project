var CommonModel = require('../models/Common');

exports.Home = function(request, response){
    response.pageInfo = {};
    response.pageInfo.pagename = 'Home';
    response.pageInfo.pagemenu = 'home';
    response.render('pages/home', response.pageInfo);
};

exports.About = function(request, response){
    /*var userList = CommonModel.list('users');*/
    CommonModel.list('users', function(data) {
        console.log(data);return false;
        // use the return value here instead of like a regular (non-evented) return value
    });
};

exports.userAction = function(request, response){
    var db = require('../config/db.js');
    db.connect(function(err) {
    if (err) throw err;
        db.query("Update users set eStatus='"+request.body.btnAction+"' where iUserID IN("+request.body.id.join()+")", function (err, result, fields) {
            if (err) throw err;
            response.redirect('/about');
        });
    });
};

exports.Gallery = function(request, response){
    response.pageInfo = {};
    response.pageInfo.pagename = 'Gallery';
    response.pageInfo.pagemenu = 'gallery';
    response.render('pages/gallery', response.pageInfo);
};

exports.Contact = function(request, response){
    response.pageInfo = {};
    response.pageInfo.pagename = 'Contact us';
    response.pageInfo.pagemenu = 'contact';
    response.render('pages/contact', response.pageInfo);
};