var HomeController = require('./controllers/HomeController');
// Routes
module.exports = function(app){
    // Main Routes
    
    app.get('/home', HomeController.Home);
    app.get('/about', HomeController.About);   
    app.get('/gallery', HomeController.Gallery);   
    app.get('/contact', HomeController.Contact);
    app.post('/userAction', HomeController.userAction);   
};
